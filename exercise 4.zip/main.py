#cars is 100
cars=100
#4.0 space in the car
space_in_a_car = 4.0
#90 passengers
passengers = 90
#no one in the car
cars_not_driven = cars-'drivers'
#driven cars equals drivers
cars_driven = 'drivers'
#cars driven multiplied by space in the car equals carpool capacity
carpool_capacity = cars_driven * space_in_a_car
#passengers=passengers
average_passengers_per_car = passengers / cars_driven
#carss available
print("there are"), cars,("cars available")
#drivers available
print("There are only"),'drivers', ("drivers available")
#will be empty cars
print ("There will be"), cars_not_driven, ("empty cars today.")
#can transport people today 
print ("We can transport"), carpool_capacity, ("people today.")
#have carpool passengers
print ("We have", passengers, "to carpool today.")
#need to put average amount in each car
print ("We need to put about"), average_passengers_per_car, ("in eachcar.")