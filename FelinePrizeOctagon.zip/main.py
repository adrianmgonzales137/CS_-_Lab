name=('zedA. Shaw')
age=35 #not a lie
height=74 #inches
weight=180 #lbs 
eyes=('blue')
teeth=('white')
hair=('brown')

print("lets talk about %s.%name")
print("He's %d inches tall %height")
print("He's %d pounds heavy %weight")
print("actually thats not too heavy.")
print("He's got %s eyes and %s hair %(eyes,hair)")
print("His teeth are usually %s depending on the coffee. %teeth")

#this line is tricky, try to get it exactly right
print("if iadd %d, %d, and %d i get %d" %(
age, height, weight, age + height + weight))

