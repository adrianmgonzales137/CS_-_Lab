print ("hello world!")
print ("hello again")
print ("i like typing this")
print ("this is fun")
print ('yay! printing.')
print (" i'd much rather you not")
print (' i said do not touch this.')

# a comment so you can read your comment later.
#anything after the # is ignored by python.

print ("i could have code like this.") # and the comment after is ignored.
#you can also use a comment to "disable" or comment out a piece of code:
# print "this wont run."

print ("this will run")

print ("i will not count my chickens:")
print ("hens", 25+30/6)
print ("roosters"), 100-25*3%4
print ("now i will count the eggs")
print (3 + 2 + 1 - 5 + 4 % 2 - 1 // 4 + 6)
print ("is it true that 3+2<5-7?")
print (3+2<5-7)
print ("what is 3+2?"), 3+2
print ("what is 5-7?"), 5-7
print ("oh thats why its false.")
print ("how about some more.")
print ("is it greater?"),5>-2
