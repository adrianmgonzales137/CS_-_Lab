x=('there are %d types of people. %d')
binary=("binary")
do_not=("dont")
y=('those who know %s and those who %s. % (binary, do_not')

print("x")
print("Y")

print("i said: %r. %x")
print("i also said: %s'. %y")

hilarious=False
joke_evaluation=("isn't that joke so funny?! %r")

print("joke evalution %hialrious")

w=("this is the side of...")
e=("a string with a right side")

print("w+e")
